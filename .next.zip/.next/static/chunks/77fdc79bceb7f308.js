__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/be254dfff9508024.js",
  "static/chunks/turbopack-fe8c2a3ac296edb2.js"
])
