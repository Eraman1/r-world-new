import { IndustryConfig } from "@/types/industries";

export const agriculture: IndustryConfig = {
  slug: "agriculture",
  banner: {
    title: "Drive Innovation with",
    highlight: "World-Class Software Development",
    subtitle:
      "Partner with expert developers to build custom, scalable, and reliable  software solutions that accelerate your business growth.",
    image:
      "https://cdn.pixabay.com/photo/2024/04/27/07/24/ai-generated-8723288_1280.jpg",
    linkText: "Get agriculture Solutions",
  },
  techHero: {
    heading:
      "Hire Experienced and Dedicated agriculture Tech Software Developers",
    description:
      "agriculture Tech solutions encompass innovative technologies transforming agriculture, boosting efficiency, profitability, and sustainability.",
    services: [
      {
        id: "land",
        title: "Land Management",
        icon: "Tractor",
        position: "left",
      },
      {
        id: "livestock",
        title: "Livestock Management",
        icon: "Beef",
        position: "left",
      },
      {
        id: "farm",
        title: "Farm Management",
        icon: "Warehouse",
        position: "left",
      },
      {
        id: "precision",
        title: "Precision Agriculture",
        icon: "Wheat",
        position: "left",
      },
      {
        id: "aquaculture",
        title: "Aquaculture",
        icon: "Fish",
        position: "right",
      },
      {
        id: "seed",
        title: "Seed-to-Sale Solutions",
        icon: "ShoppingCart",
        position: "right",
      },
      {
        id: "drone",
        title: "Agriculture Drone Software",
        icon: "PlaneTakeoff",
        position: "right",
      },
      {
        id: "food",
        title: "Food Safety & Compliance",
        icon: "FileCheck",
        position: "right",
      },
    ],
    // deviceImages: {
    //   laptop: "/images/devices/laptop-agri.png",
    //   tablet: "/images/devices/tablet-agri.png",
    //   mobile: "/images/devices/mobile-agri.png",
    // },
  },
  solutions: {
    mainTitle: "AI Solutions For Precision Agriculture",
    mainDescription:
      "AI Solutions For Precision Agriculture Our developers can implement Artificial Intelligence (AI) that analyzes data from satellites, drones, and sensors to provide real-time insights about soil conditions, moisture levels, and crop health. This data can be used to optimize irrigation, fertilization, and pest control, leading to increased yields and resource savings. Revolutionize agriculture through invaluable technology and insights that allow you to enhance productivity and resource allocation while minimizing environmental impact. Our AI solutions provide real-time data analysis, precision agriculture, and advanced crop management, enabling farmers to optimize their operations and reduce costs.",
    items: [
      {
        id: "crop-yield",
        icon: "Warehouse",
        title: "Crop Yield",
        subtitle: "Prediction & Price Forecast AI",
        description:
          "Our experts can implement AI features that predict crop yield and price. These models analyze previous data to forecast future crop yields. These predictions assist farmers in planning harvests, optimizing storage, and managing supply chains. Additionally, AI can predict price forecasts by analyzing market trends, helping farmers decide when to sell their products at the most optimal time. These factors are ever-changing, and being able to predict yield will improve crop management.",
      },
      {
        id: "chemical-spraying",
        icon: "Sprout",
        title: "Intelligent Chemical",
        subtitle: "Spraying Systems",
        description:
          "Our expert developers integrate AI technology to create advanced chemical spraying systems. With machine learning, data about temperature, soil, usage of water, and weather conditions is used to obtain useful insights to make accurate analyses. This system reduces the use of chemicals, minimizing environmental impact. It enhances crop protection while reducing the risks associated with excessive pesticide usage.",
      },
      {
        id: "seed-sowing",
        icon: "Leaf",
        title: "Predictive Analytic",
        subtitle: "Tools for Seed Sowing",
        description:
          "Our AI experts implement predictive analytics to determine the best time for seed sowing. AI analyzes data like soil health and gives fertilizer recommendations. It uses sensors that measure nutrient levels, pH, and other indicators to make these predictions, providing accurate crop insights. Additionally, it analyzes weather conditions and soil moisture levels to provide insights into optimal plating windows. This technology leads to better germination rates, healthier crops, and improved resource use.",
      },
      {
        id: "autonomous-harvesting",
        icon: "Tractor",
        title: "Autonomous",
        subtitle: "Harvesting Solutions",
        description:
          "Our developers are familiar with leveraging AI to create automated tasks. We develop autonomous harvesting solutions that utilize computer vision and machine learning algorithms to identify ripe crops and harvest them efficiently. These systems can work around the clock, reducing labor costs and improving harvest timing for optimal crop quality.",
      },
      {
        id: "crop-monitoring",
        icon: "Shield",
        title: "AI-Driven Crop",
        subtitle: "and Soil Monitoring",
        description:
          "We create AI-powered crop and soil monitoring systems to ensure crops thrive and yield a big crop yield. We use data from IoT sensors, drones, and satellite imagery to continuously monitor crop health, soil conditions, and environmental factors. This real-time monitoring enables proactive decision-making and early detection of potential issues.",
      },
      {
        id: "disease-diagnosis",
        icon: "Bug",
        title: "Machine Learning",
        subtitle: "for Disease Diagnosis",
        description:
          "Our developers are very familiar with machine learning, one of AI's powerful subsets. Machine learning is trained on datasets containing images of healthy and diseased plants to accurately identify plant diseases early. This early detection system helps farmers take immediate action, preventing crop losses and reducing the need for widespread pesticide application.",
      },
    ],
    linkText: "Get AI-Powered Agriculture Solutions",
    linkUrl: "/contact-us",
  },
  managementSolutions: {
    title: "Land Management Software Solutions",
    subtitle:
      "R-World land management software developers have vast agricultural industry-experience and first-hand knowledge of how to develop world-class solutions for agricultural operations.",
    subtitleLink: { text: "land management software", url: "#" },
    laptopImage: "/images/management-solutions.jpg",
    mobileImage: "/images/management-solutions-mobile.jpg",
    topFeatures: [
      {
        id: "mapping",
        icon: "map",
        title: "Land Mapping & GPS Software",
        description:
          "We program GIS & GPS technologies and integrate them with your current systems for site-specific data mapping optimization and accurate yield forecasting.",
        link: { text: "GIS & GPS technologies", url: "#" },
      },
      {
        id: "3d-design",
        icon: "box",
        title: "3D Field Design Applications",
        description:
          "We engineer custom 3D field design apps to seamlessly integrate with topography mapping software for added visualization and management of all land areas.",
      },
      {
        id: "sensors",
        icon: "sliders",
        title: "Smart Controllers & Sensors",
        description:
          "We implement smart controllers & sensors that screen the yields for changes in temperature, light, humidity, weather patterns, and other environmental factors.",
      },
    ],
    bottomFeatures: [
      {
        id: "autonomous",
        icon: "monitor",
        title: "Autonomous Farming Management Systems",
        description:
          "We incorporate prescriptive technology, harvesting & crop management modules, and decision support systems (DSS) to maximize operational performance for autonomous farming.",
      },
      {
        id: "irrigation",
        icon: "droplets",
        title: "Irrigation System Management",
        description:
          "We design our irrigation software with computer-aided designs (CAD), digital terrain modeling (DTM), hydraulic systems, and irrigation patterns.",
        link: { text: "irrigation software", url: "#" },
      },
      {
        id: "agronomy",
        icon: "testTube",
        title: "Agronomy Software Solutions",
        description:
          "We develop agronomy software solutions covering everything from soil sampling and collection to GIS mapping, subsurface drainage, and soil fertility automation.",
      },
      {
        id: "operations",
        icon: "settings",
        title: "Operations Management",
        description:
          "We integrate unmanned aerial vehicle (UAV) software with third-party APIs for irrigation management to streamline consistent operational workflows.",
      },
    ],
    ctaText: "GET LAND MGMT SOFTWARE DEVELOPERS",
    onCtaClick: () => {},
  },
  managementSolutionsTwo: {
  title: "Agriculture Land & Crop Management Solutions",
  subtitle:
    "Our agriculture technology experts craft intelligent land and crop management software solutions. We combine innovation, automation, and data-driven tools to help farmers and agribusinesses maximize productivity and sustainability.",
  subtitleLink: { text: "agriculture software development", url: "#" },
  laptopImage: "/images/management-solutions.jpg",
  mobileImage: "/images/management-solutions-mobile.jpg",
  topFeatures: [
    {
      id: "mapping",
      icon: "Map",
      title: "Precision Land Mapping & GPS Systems",
      description:
        "Develop intelligent GIS & GPS mapping tools for accurate land assessment and zoning. Integrate geospatial analytics for real-time decision-making.",
      link: { text: "GIS & GPS Mapping Systems", url: "#" },
    },
    {
      id: "3d-design",
      icon: "Box",
      title: "3D Terrain & Field Visualization Tools",
      description:
        "Design interactive 3D applications for topographic visualization and field analysis. Integrate with existing CAD or mapping software for seamless workflows. Enable precise irrigation layouts and contour mapping for better planning. ",
      link: { text: "3D Agricultural Design Tools", url: "#" },
    },
    {
      id: "sensors",
      icon: "Sliders",
      title: "IoT-Enabled Smart Sensors & Controllers",
      description:
        "Integrate smart IoT devices to monitor soil moisture, humidity, and temperature. Automate irrigation and nutrient supply based on real-time sensor data. Collect environmental insights for predictive farming analytics.  ",
      link: { text: "IoT Smart Farming Sensors", url: "#" },
    },
    {
      id: "crop-analytics",
      icon: "BarChart",
      title: "AI-Based Crop Health Analytics",
      description:
        "Leverage AI and computer vision to detect early signs of crop diseases. Use drone and satellite imagery for large-scale crop monitoring. Analyze growth patterns and suggest corrective agronomic actions.",
      link: { text: "AI Crop Analysis Software", url: "#" },
    },
    
    
  ],


    bottomFeatures: [
      {
        id: "autonomous",
        icon: "Monitor",
        title: "Autonomous Farming Management Systems",
        description:
          "We incorporate prescriptive technology, harvesting & crop management modules, and decision support systems (DSS) to maximize operational performance for autonomous farming.",
      },
      {
        id: "irrigation",
        icon: "Droplets",
        title: "Irrigation System Management",
        description:
          "We design our irrigation software with computer-aided designs (CAD), digital terrain modeling (DTM), hydraulic systems, and irrigation patterns.",
        link: { text: "irrigation software", url: "#" },
      },
      {
        id: "agronomy",
        icon: "TestTube",
        title: "Agronomy Software Solutions",
        description:
          "We develop agronomy software solutions covering everything from soil sampling and collection to GIS mapping, subsurface drainage, and soil fertility automation.",
      },
      {
        id: "operations",
        icon: "Settings",
        title: "Operations Management",
        description:
          "We integrate unmanned aerial vehicle (UAV) software with third-party APIs for irrigation management to streamline consistent operational workflows.",
      },
    ],
    ctaText: "GET LAND MGMT SOFTWARE DEVELOPERS",
    onCtaClick: "/contact-us",
  },
  faq: {
    title: "FAQ",
    items: [
      {
        id: "1",
        question: "What are 3D Animation Services?",
        answer:
          "3D animation services are essential for storyboarding, bringing new and engaging ideas to life. 3D animation enables character and object creation in a three-dimensional space using length, width, and depth to produce modern effects.",
      },
      {
        id: "2",
        question: "What Software is Used for 3D Animation?",
        answer:
          "Professional 3D animation software includes industry-standard tools like Maya, Blende...",
      },
      {
        id: "3",
        question: "Does Game Development Include 3D Animation?",
        answer:
          "Yes, 3D animation is a fundamental component of game development. It involves creating characters, environments, and interactive elements that bring games to life.",
      },
      {
        id: "4",
        question:
          "How is Artificial Intelligence evolving in 3D animation software?",
        answer:
          "AI is revolutionizing 3D animation by automating tedious tasks like rigging and motion capture, improving rendering speeds, and enabling real-time animation generation. Machine learning algorithms are also enhancing character animation quality.",
      },
      {
        id: "5",
        question: "What is the difference between 2D and 3D animation?",
        answer:
          "2D animation works on a flat plane with only width and height, while 3D animation adds depth to create objects and characters in three-dimensional space. 3D provides more realism and flexibility in camera movement.",
      },
      {
        id: "6",
        question:
          "How Do I Choose Between 2D and 3D Animations for my Project?",
        answer:
          "Choose 2D for stylized, cost-effective projects with fast turnaround. Select 3D when you need photorealistic visuals, complex camera movements, or dynamic interactivity. Consider your budget, timeline, and creative vision.",
      },

      // Add more items as needed
    ],
  },
};
